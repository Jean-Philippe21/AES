/**
 * @file global_vars.h
 *
 * @brief header file for global variables initialized in main.c and used in
 * other files
 *
 * @author Arnaud ROSAY
 * @date Sep 16, 2021
*/

#ifndef GLOBAL_VARS_H
#define GLOBAL_VARS_H



#endif /*GLOBAL_VARS_H */
