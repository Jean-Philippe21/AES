/**
 * @file aes_log.h
 * @brief header file for AES log
 *
 * @author Arnaud ROSAY
 * @date Sep 16, 2021
*/

#ifndef AES_LOG_H
#define AES_LOG_H
#include <stdio.h>
#include "aes.h"

/*
 * PUBLIC API
 */
#define LOG_MODE_BYTE_SEQ   0
#define LOG_MODE_MAT        1

void log_init(char *filename);
void log_deinit(void);
void log_write_block(aes_block_t *block, char *msg, uint32_t msg_length);
void log_print_block(aes_block_t *block, char *msg, uint32_t msg_length, uint32_t mode);
void log_write_key(aes_key_t *key, char *msg, uint32_t msg_length);
void log_print_key(aes_key_t *key, char *msg, uint32_t msg_length, uint32_t mode);

/*
 * PRIVATE API
 */
#ifdef AES_LOG_C
FILE *log_fp;
#endif

#endif /* AES_LOG_H */
