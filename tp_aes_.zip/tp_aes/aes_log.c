/**
 * @file aes_log.c
 * @brief AES logging functinalities
 *
 * @author Arnaud ROSAY
 * @date Sep 16, 2021
*/

#define AES_LOG_C

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>

#include "aes_log.h"

//#include "neon.h"
// #include "naive.h"
// #include "stdlib.h"
// #include "stdio.h"
// #include "string.h"
// #include "math.h"


/**
 * @brief create empty files, potentially replacing existing one
 * @param[in] filename string corresponding to the name of the log file
 * @note this function has to be called before any call to log_write_block
 */
void log_init(char *filename)
{
    /* parameter verification */
    if (filename==NULL) {
        fprintf(stderr, "[ERROR] log_init: bad input parameter\n");
        exit(EXIT_FAILURE);
    }
    /* create and open file */
    log_fp = fopen(filename, "w");
    if (errno != 0) {
        fprintf(stderr, "[ERROR] log_init errno: %d\n", errno);
        exit(EXIT_FAILURE);
    }
}

/**
 * @brief close file
 * @param filename string corresponding to the name of the log file
 * @note this function has to be called when logging in file is finished
 */
void log_deinit(void)
{
    fclose(log_fp);
    if (errno != 0) {
        fprintf(stderr, "[ERROR] log_deinit errno: %d\n", errno);
        exit(EXIT_FAILURE);
    }
}

/**
 * @brief print in the log file a block with a corresponding message
 * @param block pointer to the block structure
 * @param msg pointer to the string containing the message
 * @param msg_length message length
 */
void log_write_block(aes_block_t *block, char *msg, uint32_t msg_length)
{
    /* parameter verification */
    if (block == NULL) {
        fprintf(stderr, "[ERROR] log_write_block: bad input parameter\n");
        exit(EXIT_FAILURE);
    }
    if ((msg != NULL) && (strlen(msg)==msg_length)) {
        fprintf(log_fp, "%s:\t", msg);
    }
    for (uint32_t i=0;i<AES_BLOCK_SIZE;i++) {
        fprintf(log_fp, "%02x", block->byte[i]);
    }
    fprintf(log_fp, "\n");
}

/**
 * @brief print a block with a corresponding message
 * @param block pointer to the block structure
 * @param msg pointer to the string containing the message
 * @param msg_length message length
 * @param mode supported value are 0 and 1. if mode=0, the block is printed as
 * a byte sequence. if mode=1, the block is printed as a matrix
 */
void log_print_block(aes_block_t *block, char *msg, uint32_t msg_length, uint32_t mode)
{
    /* parameter verification */
    if ((block == NULL) || (mode>1)) {
        fprintf(stderr, "[ERROR] log_print_block_line: bad input parameter\n");
        exit(EXIT_FAILURE);
    }
    if ((msg != NULL) && (strlen(msg)==msg_length)) {
        printf("%s:\t", msg);
    }
    if (mode == 0) {
        for (uint32_t i = 0; i < AES_BLOCK_SIZE; i++) {
            printf("%02x", block->byte[i]);
        }
        printf("\n");
    } else {
        printf("\n");
        for (uint32_t i=0;i<4;i++) {
            printf("%02x %02x %02x %02x\n",
                   block->mat[i][0], block->mat[i][1], block->mat[i][2], block->mat[i][3]);
        }
    }
}

/**
 * @brief print in the log file a block with a corresponding message
 * @param block pointer to the block structure
 * @param msg pointer to the string containing the message
 * @param msg_length message length
 */
void log_write_key(aes_key_t *key, char *msg, uint32_t msg_length)
{
    /* parameter verification */
    if (key == NULL) {
        fprintf(stderr, "[ERROR] log_write_key: bad input parameter\n");
        exit(EXIT_FAILURE);
    }
    if ((msg != NULL) && (strlen(msg)==msg_length)) {
        fprintf(log_fp, "%s:\t", msg);
    }
    for (uint32_t i=0;i<key->length;i++) {
        fprintf(log_fp, "%02x", key->byte[i]);
    }
    fprintf(log_fp, "\n");
}

/**
 * @brief print a key with a corresponding message
 * @param key pointer to the key structure
 * @param msg pointer to the string containing the message
 * @param msg_length message length
 * @param mode supported value are 0 and 1. if mode=0, the block is printed as
 * a byte sequence. if mode=1, the block is printed as a matrix
 */
void log_print_key(aes_key_t *key, char *msg, uint32_t msg_length, uint32_t mode)
{
    /* parameter verification */
    if ((key == NULL) || (mode>1)) {
        fprintf(stderr, "[ERROR] log_print_block_line: bad input parameter\n");
        exit(EXIT_FAILURE);
    }
    if ((msg != NULL) && (strlen(msg)==msg_length)) {
        printf("%s:\t", msg);
    }
    if (mode == 0) {
        for (uint32_t i = 0; i < key->length; i++) {
            printf("%02x", key->byte[i]);
        }
        printf("\n");
    } else {
        uint32_t nk=0;
        switch (key->length) {
            case AES128_KEY_SIZE/8:
                nk = AES128_NK;
                break;
            case AES192_KEY_SIZE/8:
                nk = AES192_NK;
                break;
            case AES256_KEY_SIZE/8:
                nk = AES256_NK;
                break;
            default:
                fprintf(stderr, "[ERROR] aes_key2mat: bad input parameter\n");
        }
        printf("\n");
        for (uint32_t r=0;r<4;r++) {
            for (uint32_t c=0;c<nk;c++) {
                printf("%02x ", key->mat[r][c]);
            }
            printf("\n");
        }
    }
}

#undef AES_LOG_C
