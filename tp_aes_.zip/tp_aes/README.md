# TP AES

Les consignes pour ce TP sur l'AES se trouvent dans le fichier TP_AES.pdf.
Vous devrez remplir le fichier et m'envoyer par mail (arnaud.rosay.etu@univ-lemans.fr) un fichier zip 
contenant le fichier rempli ainsi que votre code que je dois être capable de recompiler pour vérifier vos résultats.

Le fichier refman.pdf contient la documentation générée automatiquement par Doxygen sur le code complet qui devrait 
être obtenu à la fin du TP.
